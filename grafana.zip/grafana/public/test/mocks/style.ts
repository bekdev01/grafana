export const style = 'style';
